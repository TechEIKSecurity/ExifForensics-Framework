#!/bin/bash

## --- Configurações ---
# Cores
COLOR_PRIMARY='\033[38;5;99m'    # Roxo profundo
COLOR_ACCENT='\033[38;5;45m'     # Azul ciano
COLOR_SUCCESS='\033[38;5;118m'   # Verde claro
COLOR_RESET='\033[0m'            # Reset

# Caracteres do Spinner
SPINNER_FRAMES=('⠋' '⠙' '⠹' '⠸' '⠼' '⠴' '⠦' '⠧' '⠇' '⠏')
FRAME_DELAY=0.1

## --- Funções Bem Estruturadas ---
cleanup() {
    # Garante que o spinner seja interrompido corretamente
    if [[ -n $SPINNER_PID ]]; then
        kill $SPINNER_PID >/dev/null 2>&1
        wait $SPINNER_PID 2>/dev/null
    fi
    tput cnorm  # Restaura o cursor
    exit 0
}

show_spinner() {
    tput civis  # Esconde o cursor
    local message="$1"
    while true; do
        for frame in "${SPINNER_FRAMES[@]}"; do
            printf "\r${COLOR_PRIMARY}%s${COLOR_RESET} ${COLOR_ACCENT}%s${COLOR_RESET}" "$message" "$frame"
            sleep $FRAME_DELAY
        done
    done
}

## --- Tratamento de Interrupção ---
trap cleanup EXIT INT TERM

## --- Execução Principal ---
{
    # Inicia o spinner em background
    show_spinner "Forense Framework" &
    SPINNER_PID=$!
   
    # um processo (substitua pelo seu código real)
    sleep 5
   
    # Finalização limpa
    cleanup
    
    # Mensagem de sucesso
clear   
 printf "\r${COLOR_PRIMARY}Forense Framework${COLOR_RESET} ${COLOR_SUCCESS}✓ Concluído com sucesso!${COLOR_RESET}\n"
} 2>/dev/null

